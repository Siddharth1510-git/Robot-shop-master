#!/bin/sh

# signal that the import has finsihed
touch /tmp/finished

